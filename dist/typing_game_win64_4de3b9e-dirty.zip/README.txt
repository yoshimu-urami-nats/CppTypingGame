﻿Typing Game - 簡易版

【起動】
1) typing_game.exe をダブルクリック

【遊び方】
- 画面に出る「お題（日本語）」を見て、ローマ字で入力して Enter
  例）ぷーちく → pu-tiku / メンゴ → mengo

【動作環境】
- Windows 10/11 (同梱DLL必須)
